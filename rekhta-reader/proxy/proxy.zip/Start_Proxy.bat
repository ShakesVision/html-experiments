@echo off
echo Starting Secure Local Proxy...
caddy.exe run --config Caddyfile
pause
